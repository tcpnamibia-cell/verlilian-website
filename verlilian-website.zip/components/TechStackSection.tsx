import { TECH_STACK } from "@/lib/constants";

export default function TechStackSection() {
  return (
    <section id="tech" className="py-20 px-6 bg-white">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
          Built on Modern Infrastructure
        </h2>
        <p className="text-slate-600 mb-12">
          Our technical stack is chosen for reliability, scalability, and rapid
          iteration.
        </p>
        <div className="grid grid-cols-3 gap-8">
          {TECH_STACK.map((tech) => (
            <div
              key={tech.name}
              className="p-6 rounded-xl border border-slate-200 hover:border-slate-400 transition-colors"
            >
              <div className="text-4xl mb-4">{tech.icon}</div>
              <h3 className="font-bold text-slate-900 mb-2">{tech.name}</h3>
              <p className="text-sm text-slate-600">{tech.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
