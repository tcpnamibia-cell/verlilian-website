import { COMPANY } from "@/lib/constants";

export default function ContactSection() {
  return (
    <section id="contact" className="py-20 px-6 bg-emerald-50">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className="grid md:grid-cols-2">
            <div className="p-10 bg-emerald-700 text-white">
              <h2 className="text-3xl font-bold mb-6">Let's Connect</h2>
              <p className="text-emerald-100 mb-8 leading-relaxed">
                We are actively seeking partners, collaborators, and pilot users
                as we prepare for the Google Africa Applied AI Lab.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center">
                    📍
                  </div>
                  <div>
                    <div className="font-semibold">Address</div>
                    <div className="text-emerald-100 text-sm">
                      {COMPANY.address}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center">
                    ✉️
                  </div>
                  <div>
                    <div className="font-semibold">Email</div>
                    <div className="text-emerald-100 text-sm">
                      {COMPANY.email}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center">
                    🏢
                  </div>
                  <div>
                    <div className="font-semibold">Registration</div>
                    <div className="text-emerald-100 text-sm">
                      {COMPANY.regNumber}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="p-10 flex flex-col justify-center">
              <h3 className="text-xl font-bold text-slate-900 mb-4">
                Application Status
              </h3>
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl mb-6">
                <div className="flex items-center gap-2 text-amber-800 font-semibold mb-1">
                  <span className="w-2 h-2 bg-amber-500 rounded-full animate-pulse" />
                  Google Africa Applied AI Lab — In Progress
                </div>
                <p className="text-amber-700 text-sm">
                  Deadline: August 31st, 2026
                </p>
              </div>
              <p className="text-slate-600 text-sm leading-relaxed">
                {COMPANY.name} is a Namibian-registered close corporation
                committed to building technology that serves real African
                problems with honesty and precision.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
