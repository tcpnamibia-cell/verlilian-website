import { PROBLEMS } from "@/lib/constants";

export default function ProblemSection() {
  return (
    <section id="problem" className="py-20 px-6 bg-white">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
            The Challenge We Address
          </h2>
          <p className="text-slate-600 max-w-2xl mx-auto">
            African agriculture faces systemic barriers that technology can help overcome.
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {PROBLEMS.map((problem) => (
            <div
              key={problem.title}
              className="p-8 rounded-2xl bg-slate-50 border border-slate-100 hover:shadow-lg transition-shadow"
            >
              <div
                className={`w-12 h-12 ${problem.bgColor} ${problem.textColor} rounded-xl flex items-center justify-center text-2xl mb-6`}
              >
                {problem.icon}
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">
                {problem.title}
              </h3>
              <p className="text-slate-600 leading-relaxed">
                {problem.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
