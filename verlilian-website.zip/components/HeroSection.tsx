import { COMPANY, HERO } from "@/lib/constants";

export default function HeroSection() {
  return (
    <section className="pt-32 pb-20 px-6 bg-gradient-to-b from-emerald-50/50 to-white">
      <div className="max-w-4xl mx-auto text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-100 text-emerald-800 rounded-full text-sm font-medium mb-8">
          <span className="w-2 h-2 bg-emerald-600 rounded-full animate-pulse" />
          {COMPANY.country} · {COMPANY.regNumber}
        </div>
        <h1 className="text-4xl md:text-6xl font-bold text-slate-900 leading-tight mb-6 tracking-tight">
          AI-Native Solutions for{" "}
          <span className="text-emerald-700">African Agriculture</span> & Logistics
        </h1>
        <p className="text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed mb-10">
          {HERO.description}
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href="#solution"
            className="px-8 py-4 bg-emerald-700 text-white rounded-xl font-semibold hover:bg-emerald-800 transition-all shadow-lg shadow-emerald-700/20"
          >
            Explore Our Approach
          </a>
          <a
            href="#contact"
            className="px-8 py-4 bg-white text-emerald-700 border-2 border-emerald-700 rounded-xl font-semibold hover:bg-emerald-50 transition-all"
          >
            Get in Touch
          </a>
        </div>
      </div>
    </section>
  );
}
