import { COMPANY } from "@/lib/constants";

export default function Footer() {
  return (
    <footer className="py-8 px-6 bg-slate-900 text-slate-400 text-center text-sm">
      <p>
        © 2026 {COMPANY.name} ({COMPANY.regNumber}). All rights reserved.
        Walvis Bay, Namibia.
      </p>
    </footer>
  );
}
