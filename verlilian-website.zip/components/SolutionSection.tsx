import { SOLUTIONS } from "@/lib/constants";

export default function SolutionSection() {
  return (
    <section id="solution" className="py-20 px-6 bg-slate-900 text-white">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Our AI-Driven Approach
            </h2>
            <p className="text-slate-300 text-lg leading-relaxed mb-8">
              We treat artificial intelligence as a practical tool—not a buzzword.
              Our systems are designed specifically for the realities of African
              farming and logistics operations.
            </p>
            <div className="space-y-6">
              {SOLUTIONS.map((solution) => (
                <div key={solution.step} className="flex gap-4">
                  <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center flex-shrink-0 font-bold">
                    {solution.step}
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg">{solution.title}</h4>
                    <p className="text-slate-400">{solution.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-3 h-3 bg-red-500 rounded-full" />
              <div className="w-3 h-3 bg-amber-500 rounded-full" />
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="text-slate-400 text-sm ml-2 font-mono">
                verlilian-ai-core
              </span>
            </div>
            <div className="font-mono text-sm space-y-3 text-slate-300">
              <div className="text-emerald-400">// Real-time crop analysis</div>
              <div>
                <span className="text-purple-400">analyze</span>(field_id,{" "}
                <span className="text-amber-400">image_data</span>)
              </div>
              <div className="pl-4 text-slate-500">
                → Detecting: Leaf rust probability 12%
              </div>
              <div className="pl-4 text-slate-500">
                → Recommendation: Increase nitrogen, monitor weekly
              </div>
              <div className="mt-4 text-emerald-400">// Supply chain routing</div>
              <div>
                <span className="text-purple-400">optimize_route</span>(origin,{" "}
                <span className="text-amber-400">market_demand</span>)
              </div>
              <div className="pl-4 text-slate-500">
                → Route: Gobabis → Windhoek (saved 34% fuel)
              </div>
              <div className="pl-4 text-slate-500">
                → ETA: 4.2 hours | Market price: N$ 18.50/kg
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
